import 'package:flutter/material.dart';

const bg = Color(0xFF111418);
const card = Color(0xFF1B1F27);
const cardAlt = Color(0xFF2A2D35);
const accent = Color(0xFFFF4D57);
const success = Color(0xFF22C55E);
const danger = Color(0xFFEF4444);
const textMuted = Color(0xFF9CA3AF);
const divider = Color(0xFF323844);

const unrealTextTheme = TextTheme(
  titleLarge: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
  bodyLarge: TextStyle(fontSize: 16),
  bodySmall: TextStyle(fontSize: 12),
);

ThemeData buildAppTheme() {
  return ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: bg,
    colorScheme: const ColorScheme.dark(
      primary: accent,
      onPrimary: Colors.white,
      secondary: cardAlt,
      onSecondary: Colors.white,
      surface: card,
      onSurface: Colors.white,
      error: danger,
      onError: Colors.white,
      outline: divider,
    ),
    textTheme: unrealTextTheme,
    fontFamily: 'Roboto',
    useMaterial3: true,
    appBarTheme: const AppBarTheme(backgroundColor: bg, elevation: 0),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: card,
      hintStyle: const TextStyle(color: textMuted),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.all(Radius.circular(12)),
        borderSide: BorderSide.none,
      ),
    ),
  );
}
