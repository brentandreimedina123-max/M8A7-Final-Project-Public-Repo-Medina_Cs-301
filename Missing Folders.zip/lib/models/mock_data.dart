import 'package:flutter/material.dart';
import '../theme.dart';

class GameMatch {
  final String id, game, time, league, startsIn;
  final String teamA, teamB, scoreA, scoreB;
  final bool live, finished;
  const GameMatch({required this.id, required this.game, required this.time, required this.league, required this.startsIn, required this.teamA, required this.teamB, required this.scoreA, required this.scoreB, this.live = false, this.finished = false});
}

class FeedItem {
  final IconData icon;
  final Color iconColor;
  final String title, subtitle, time;
  final bool isUpdate;
  const FeedItem(this.icon, this.iconColor, this.title, this.subtitle, this.time, {this.isUpdate = false});
}

const games = ['VAL', 'CS2', 'LoL', 'DOTA 2', 'R6', 'OW2', 'RL'];

const matches = [
  GameMatch(id:'m1', game:'VAL', time:'7:00 PM', league:'VCT Americas', startsIn:'Starts in 5h 2m', teamA:'SEN', teamB:'PRX', scoreA:'0', scoreB:'0'),
  GameMatch(id:'m2', game:'VAL', time:'8:30 PM', league:'VCT EMEA', startsIn:'Starts in 6h 32m', teamA:'G2', teamB:'FNC', scoreA:'0', scoreB:'0'),
  GameMatch(id:'m3', game:'VAL', time:'10:00 PM', league:'VCT Pacific', startsIn:'Starts in 8h 2m', teamA:'T1', teamB:'GEN', scoreA:'0', scoreB:'0'),
  GameMatch(id:'m4', game:'CS2', time:'6:00 PM', league:'ESL Pro League', startsIn:'Starts in 4h 2m', teamA:'NAVI', teamB:'3DMAX', scoreA:'0', scoreB:'0'),
  GameMatch(id:'m5', game:'LoL', time:'9:00 PM', league:'LCK', startsIn:'Starts in 7h 2m', teamA:'T1', teamB:'GEN', scoreA:'0', scoreB:'0'),
  GameMatch(id:'m6', game:'DOTA 2', time:'11:00 PM', league:'DreamLeague', startsIn:'Starts in 9h 2m', teamA:'GG', teamB:'XG', scoreA:'0', scoreB:'0'),
];

const liveMatches = [
  GameMatch(id:'l1', game:'VAL', time:'LIVE', league:'VCT Americas', startsIn:'Map 2 • Round 8', teamA:'SEN', teamB:'PRX', scoreA:'6', scoreB:'5', live:true),
  GameMatch(id:'l2', game:'CS2', time:'LIVE', league:'ESL Pro League', startsIn:'Mirage • Round 19', teamA:'NAVI', teamB:'3DMAX', scoreA:'10', scoreB:'8', live:true),
];

const feed = [
  FeedItem(Icons.person, Colors.orange, 'TenZ', 'Posted a new clip', '1h'),
  FeedItem(Icons.emoji_events, accent, 'VCT Americas Stage 2', 'Schedule updated', '2h'),
  FeedItem(Icons.shield, Colors.purple, 'PRX', 'd4v41 is doubtful for today\'s match', '3h', isUpdate: true),
  FeedItem(Icons.newspaper, accent, 'VALORANT Patch 9.08', 'Full patch notes', '5h'),
];

const followed = ['Sentinels', 'TenZ', 'VCT Americas Stage 2'];

class Player {
  final String id, name, realName, team, game, role, country, number, bio;
  const Player({required this.id, required this.name, required this.realName, required this.team, required this.game, required this.role, required this.country, required this.number, required this.bio});
}

class TeamInfo {
  final String name, game, region, description;
  final List<String> playerIds;
  const TeamInfo({required this.name, required this.game, required this.region, required this.description, required this.playerIds});
}

const players = [
  Player(id:'p1', name:'TenZ', realName:'Tyson Van Nguyen', team:'Sentinels', game:'VAL', role:'Duelist / Content Creator', country:'Canada', number:'1', bio:'One of the most recognizable VALORANT players and creators, known for his mechanical aim and aggressive style.'),
  Player(id:'p2', name:'johnqt', realName:'Mohamed Amine Ouarid', team:'Sentinels', game:'VAL', role:'IGL / Controller', country:'Morocco', number:'2', bio:'Sentinels in-game leader known for calm mid-round calls and strong utility usage.'),
  Player(id:'p3', name:'zekken', realName:'Zachary Patrone', team:'Sentinels', game:'VAL', role:'Duelist', country:'United States', number:'3', bio:'A high-impact duelist with fast entries and excellent movement.'),
  Player(id:'p4', name:'d4v41', realName:'Khalish Rusyaidee', team:'Paper Rex', game:'VAL', role:'Initiator / Flex', country:'Malaysia', number:'4', bio:'A flexible player known for smart utility and adaptable play.'),
  Player(id:'p5', name:'something', realName:'Ilya Petrov', team:'Paper Rex', game:'VAL', role:'Duelist', country:'Russia', number:'5', bio:'An explosive mechanical player who can take over rounds with aggressive openings.'),
  Player(id:'p6', name:'Jinggg', realName:'Wang Jing Jie', team:'Paper Rex', game:'VAL', role:'Duelist', country:'Singapore', number:'6', bio:'A fearless entry player recognized for fast-paced fights and confident plays.'),
  Player(id:'p7', name:'cNed', realName:'Mehmet Yağız İpek', team:'NAVI', game:'CS2', role:'AWPer', country:'Türkiye', number:'7', bio:'A veteran AWPer known for sharp opening picks and clutch potential.'),
  Player(id:'p8', name:'w0nderful', realName:'Ihor Zhdanov', team:'NAVI', game:'CS2', role:'AWPer', country:'Ukraine', number:'8', bio:'A precise AWPer with strong positioning and consistent impact.'),
  Player(id:'p9', name:'Aleksib', realName:'Aleksi Virolainen', team:'NAVI', game:'CS2', role:'IGL', country:'Finland', number:'9', bio:'Experienced in-game leader known for structured tactical calling.'),
  Player(id:'p10', name:'m0NESY', realName:'Ilya Osipov', team:'G2', game:'CS2', role:'AWPer', country:'Russia', number:'10', bio:'A star AWPer with exceptional speed, aim and clutch ability.'),
  Player(id:'p11', name:'huNter-', realName:'Nemanja Kovač', team:'G2', game:'CS2', role:'Rifler', country:'Bosnia and Herzegovina', number:'11', bio:'A veteran rifler known for strong positioning and multi-kill rounds.'),
  Player(id:'p12', name:'Caps', realName:'Rasmus Winther', team:'G2', game:'LoL', role:'Mid Laner', country:'Denmark', number:'12', bio:'A creative mid laner known for aggressive champion picks and playmaking.'),

  Player(id:'p13', name:'Chronicle', realName:'Timofey Khromov', team:'Fnatic', game:'VAL', role:'Flex', country:'Russia', number:'13', bio:'A versatile player known for disciplined utility and strong mid-round decisions.'),
  Player(id:'p14', name:'Boaster', realName:'Jake Howlett', team:'Fnatic', game:'VAL', role:'IGL / Controller', country:'United Kingdom', number:'14', bio:'An experienced leader known for preparation, calling and energetic performances.'),
  Player(id:'p15', name:'crashies', realName:'Austin Roberts', team:'Fnatic', game:'VAL', role:'Initiator', country:'United States', number:'15', bio:'A reliable initiator with strong utility timing and team play.'),
  Player(id:'p16', name:'f0rsakeN', realName:'Jason Susanto', team:'T1', game:'VAL', role:'Duelist / Flex', country:'Indonesia', number:'16', bio:'A creative mechanical player known for unconventional plays and sharp aim.'),
  Player(id:'p17', name:'carpe', realName:'Lee Jae-hyeok', team:'T1', game:'VAL', role:'Flex', country:'South Korea', number:'17', bio:'A veteran esports competitor with strong experience and clutch instincts.'),
  Player(id:'p18', name:'Meteor', realName:'Kim Tae-o', team:'T1', game:'VAL', role:'Sentinel', country:'South Korea', number:'18', bio:'A steady defensive player with strong site control and timing.'),
  Player(id:'p19', name:'t3xture', realName:'Kim Na-ra', team:'Gen.G', game:'VAL', role:'Duelist', country:'South Korea', number:'19', bio:'An explosive duelist capable of creating opening advantages.'),
  Player(id:'p20', name:'Munchkin', realName:'Byeon Sang-beom', team:'Gen.G', game:'VAL', role:'IGL / Controller', country:'South Korea', number:'20', bio:'A veteran leader known for structured calling and calm decision making.'),
  Player(id:'p21', name:'Karon', realName:'Kim Won-tae', team:'Gen.G', game:'VAL', role:'Controller', country:'South Korea', number:'21', bio:'A composed controller with excellent utility discipline.'),
  Player(id:'p22', name:'dexter', realName:'Chris Nong', team:'3DMAX', game:'CS2', role:'IGL', country:'Australia', number:'22', bio:'An experienced in-game leader known for tactical structure.'),
  Player(id:'p23', name:'Lucky', realName:'Lukas Berndt', team:'3DMAX', game:'CS2', role:'AWPer', country:'Denmark', number:'23', bio:'A young AWPer with strong mechanical potential.'),
  Player(id:'p24', name:'Maka', realName:'Maka', team:'3DMAX', game:'CS2', role:'AWPer', country:'France', number:'24', bio:'A veteran CS2 player known for confident AWPing and opening kills.'),
  Player(id:'p25', name:'Quinn', realName:'Quinn Callahan', team:'Gaimin Gladiators', game:'DOTA 2', role:'Mid Laner', country:'United States', number:'25', bio:'An aggressive mid laner known for creating pressure around the map.'),
  Player(id:'p26', name:'Ace', realName:'Watson', team:'Gaimin Gladiators', game:'DOTA 2', role:'Carry', country:'Kazakhstan', number:'26', bio:'A mechanically skilled carry focused on efficient farming and late-game impact.'),
  Player(id:'p27', name:'Seleri', realName:'Melchior Hillenkamp', team:'Gaimin Gladiators', game:'DOTA 2', role:'Support', country:'Germany', number:'27', bio:'A support player known for leadership and strong map awareness.'),
  Player(id:'p28', name:'Xm', realName:'Daniel Shen', team:'Xtreme Gaming', game:'DOTA 2', role:'Mid Laner', country:'China', number:'28', bio:'A high-level mid player known for aggressive lane control.'),
  Player(id:'p29', name:'Ame', realName:'Wang Chunyu', team:'Xtreme Gaming', game:'DOTA 2', role:'Carry', country:'China', number:'29', bio:'A veteran carry known for efficient farming and clutch team fights.'),
  Player(id:'p30', name:'Dy', realName:'Ding Cong', team:'Xtreme Gaming', game:'DOTA 2', role:'Support', country:'China', number:'30', bio:'A veteran support known for vision control and team fight execution.'),
];

const teams = [
  TeamInfo(name:'Sentinels', game:'VAL', region:'Americas', description:'A North American VALORANT organization known for its aggressive style and huge fanbase.', playerIds:['p1','p2','p3']),
  TeamInfo(name:'Paper Rex', game:'VAL', region:'Pacific', description:'A Pacific powerhouse famous for its fast, unpredictable and fearless style.', playerIds:['p4','p5','p6']),
  TeamInfo(name:'NAVI', game:'CS2', region:'Europe', description:'A historic esports organization competing at the highest level across multiple titles.', playerIds:['p7','p8','p9']),
  TeamInfo(name:'G2', game:'CS2 / LoL', region:'Americas', description:'A major esports organization with elite teams and players across competitive games.', playerIds:['p10','p11','p12']),
  TeamInfo(name:'Fnatic', game:'VAL', region:'EMEA', description:'A European esports organization with a long history of competing at the highest level.', playerIds:['p13','p14','p15']),
  TeamInfo(name:'T1', game:'VAL', region:'Pacific', description:'A legendary esports organization with a deep competitive history.', playerIds:['p16','p17','p18']),
  TeamInfo(name:'Gen.G', game:'VAL', region:'Pacific', description:'A Korean powerhouse known for disciplined team play and elite mechanics.', playerIds:['p19','p20','p21']),
  TeamInfo(name:'3DMAX', game:'CS2', region:'Europe', description:'A competitive CS2 roster built around tactical play and individual firepower.', playerIds:['p22','p23','p24']),
  TeamInfo(name:'Gaimin Gladiators', game:'DOTA 2', region:'Europe', description:'A top-level DOTA 2 organization known for aggressive drafts and coordinated team fights.', playerIds:['p25','p26','p27']),
  TeamInfo(name:'Xtreme Gaming', game:'DOTA 2', region:'China', description:'A Chinese DOTA 2 organization featuring experienced players and strong team fighting.', playerIds:['p28','p29','p30']),
];

final ValueNotifier<Set<String>> favoriteItems = ValueNotifier<Set<String>>({...followed});

bool isFavorite(String id) => favoriteItems.value.contains(id);
void toggleFavorite(String id) {
  final updated = {...favoriteItems.value};
  if (!updated.add(id)) updated.remove(id);
  favoriteItems.value = updated;
}
