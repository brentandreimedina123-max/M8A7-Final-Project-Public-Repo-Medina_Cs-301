import 'package:flutter/material.dart';
import 'theme.dart';
import 'tabs/home_tab.dart';
import 'tabs/esports_tab.dart';
import 'tabs/following_tab.dart';
import 'tabs/profile_tab.dart';

class RootShell extends StatefulWidget { const RootShell({super.key}); @override State<RootShell> createState()=>_RootShellState(); }
class _RootShellState extends State<RootShell> {
 int _index=0;
 void goTo(int index)=>setState(()=>_index=index);
 @override Widget build(BuildContext context){
   final tabs=[HomeTab(onGoTo:goTo),const EsportsTab(),FollowingTab(onGoTo:goTo),const ProfileTab()];
   return Scaffold(body:SafeArea(child:IndexedStack(index:_index,children:tabs)),bottomNavigationBar:NavigationBar(backgroundColor:card,indicatorColor:accent.withValues(alpha: .18),selectedIndex:_index,onDestinationSelected:goTo,destinations:const[
     NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
     NavigationDestination(icon:Icon(Icons.emoji_events_outlined),selectedIcon:Icon(Icons.emoji_events),label:'Esports'),
     NavigationDestination(icon:Icon(Icons.star_border),selectedIcon:Icon(Icons.star),label:'Following'),
     NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile'),
   ]));
 }
}
