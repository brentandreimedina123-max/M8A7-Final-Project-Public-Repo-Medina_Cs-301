import 'package:flutter/material.dart';
import 'theme.dart';
import 'root_shell.dart';
void main(){runApp(const EsportsApp());}
class EsportsApp extends StatelessWidget{const EsportsApp({super.key});@override Widget build(BuildContext context)=>MaterialApp(title:'UnReal Time',debugShowCheckedModeBanner:false,theme:buildAppTheme(),home:const RootShell());}
