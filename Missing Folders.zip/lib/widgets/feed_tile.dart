import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/mock_data.dart';

class FeedTile extends StatelessWidget {
  final FeedItem item;
  final VoidCallback? onTap;
  const FeedTile({super.key, required this.item, this.onTap});
  @override Widget build(BuildContext context) => InkWell(onTap:onTap,child:Padding(padding:const EdgeInsets.symmetric(horizontal:16,vertical:10),child:Row(children:[CircleAvatar(backgroundColor:cardAlt,child:Icon(item.icon,color:item.iconColor,size:20)),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(item.title,style:const TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:3),Text(item.subtitle,style:const TextStyle(color:textMuted,fontSize:13))])),item.isUpdate?const Text('Update',style:TextStyle(color:accent,fontWeight:FontWeight.bold,fontSize:12)):Text(item.time,style:const TextStyle(color:textMuted,fontSize:12))])));
}
