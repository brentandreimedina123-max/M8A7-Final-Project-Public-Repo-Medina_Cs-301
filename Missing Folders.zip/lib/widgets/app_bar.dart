import 'package:flutter/material.dart';

class UnrealAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onSearch;
  final VoidCallback? onNotifications;
  const UnrealAppBar({super.key, required this.title, this.onSearch, this.onNotifications});
  @override Size get preferredSize => const Size.fromHeight(58);
  @override Widget build(BuildContext context) => AppBar(title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),actions:[if(onSearch!=null)IconButton(onPressed:onSearch,icon:const Icon(Icons.search_rounded)),if(onNotifications!=null)IconButton(onPressed:onNotifications,icon:const Icon(Icons.notifications_none_rounded))]);
}
