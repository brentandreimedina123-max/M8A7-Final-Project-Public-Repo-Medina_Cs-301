import 'package:flutter/material.dart';
class SearchField extends StatelessWidget {
 final TextEditingController controller; final String hint; final ValueChanged<String>? onChanged;
 const SearchField({super.key,required this.controller,this.hint='Search teams, tournaments, or games',this.onChanged});
 @override Widget build(BuildContext context)=>TextField(controller:controller,onChanged:onChanged,decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:hint));
}
