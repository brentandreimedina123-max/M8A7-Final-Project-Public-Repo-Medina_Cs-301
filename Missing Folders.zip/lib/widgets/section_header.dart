import 'package:flutter/material.dart';
import '../theme.dart';
class SectionHeader extends StatelessWidget {
 final String title; final String? actionText; final VoidCallback? onAction;
 const SectionHeader({super.key,required this.title,this.actionText,this.onAction});
 @override Widget build(BuildContext context)=>Padding(padding:const EdgeInsets.fromLTRB(16,18,16,10),child:Row(children:[Expanded(child:Text(title,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold))),if(actionText!=null)TextButton(onPressed:onAction,child:Text(actionText!,style:const TextStyle(color:accent))) ]));
}
