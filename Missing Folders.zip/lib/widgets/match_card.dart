import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/mock_data.dart';

class MatchCard extends StatelessWidget {
  final GameMatch match;
  final VoidCallback? onTap;

  const MatchCard({super.key, required this.match, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: card,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: 136),
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: divider),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      match.live ? 'LIVE' : match.time,
                      style: const TextStyle(fontWeight: FontWeight.bold),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (match.live)
                    const StatusBadge(label: 'LIVE', color: success),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: _TeamBadge(match.teamA, match.scoreA)),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 5),
                    child: Text('VS', style: TextStyle(color: textMuted, fontSize: 10)),
                  ),
                  Expanded(child: _TeamBadge(match.teamB, match.scoreB)),
                ],
              ),
              const SizedBox(height: 7),
              Text(
                match.league,
                style: const TextStyle(fontSize: 10, color: textMuted),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 1),
              Text(
                match.startsIn,
                style: const TextStyle(fontSize: 10, color: textMuted),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class StatusBadge extends StatelessWidget {
  final String label;
  final Color color;

  const StatusBadge({super.key, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .14),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold),
      ),
    );
  }
}

class _TeamBadge extends StatelessWidget {
  final String name;
  final String score;

  const _TeamBadge(this.name, this.score);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        CircleAvatar(
          radius: 14,
          backgroundColor: cardAlt,
          child: Text(
            name.isEmpty ? '?' : name[0],
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
          ),
        ),
        const SizedBox(height: 2),
        Text(
          name,
          style: const TextStyle(fontSize: 9, fontWeight: FontWeight.bold),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
        ),
        Text(
          score,
          style: const TextStyle(fontSize: 9, color: textMuted),
          maxLines: 1,
        ),
      ],
    );
  }
}
