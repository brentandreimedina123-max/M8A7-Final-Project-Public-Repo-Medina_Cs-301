import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/mock_data.dart';
import '../widgets/match_card.dart';
import '../widgets/feed_tile.dart';
import '../widgets/section_header.dart';
import '../widgets/app_bar.dart';
import 'match_detail.dart';

class HomeTab extends StatefulWidget {
  final ValueChanged<int>? onGoTo;
  const HomeTab({super.key, this.onGoTo});
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  int gameIndex = 0;
  int subTab = 0;
  final List<String> subs = ['Feed', 'Matches', 'News', 'Rankings'];

  @override
  Widget build(BuildContext context) {
    final selectedGame = games[gameIndex];
    final filtered = matches.where((m) => m.game == selectedGame).toList();

    return CustomScrollView(
      slivers: [
        const SliverToBoxAdapter(child: SizedBox(height: 6)),
        SliverToBoxAdapter(
          child: UnrealAppBar(
            title: 'UnReal Time',
            onSearch: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SearchPage()),
            ),
          ).build(context),
        ),

        // Game filters
        SliverToBoxAdapter(
          child: SizedBox(
            height: 52,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              scrollDirection: Axis.horizontal,
              itemCount: games.length,
              separatorBuilder: (_, __) => const SizedBox(width: 18),
              itemBuilder: (_, i) {
                final selected = i == gameIndex;
                return GestureDetector(
                  onTap: () => setState(() {
                    gameIndex = i;
                    subTab = 0;
                  }),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    decoration: BoxDecoration(
                      color: selected ? accent.withValues(alpha: .14) : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: selected ? accent : divider),
                    ),
                    child: Center(
                      child: Text(
                        games[i],
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: selected ? accent : textMuted,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ),

        // Live now
        SliverToBoxAdapter(
          child: SectionHeader(
            title: 'Live Now',
            actionText: 'See all',
            onAction: () => widget.onGoTo?.call(1),
          ),
        ),
        SliverToBoxAdapter(
          child: _ResponsiveMatchList(
            matches: liveMatches,
            context: context,
          ),
        ),

        // Upcoming
        SliverToBoxAdapter(
          child: SectionHeader(
            title: 'Upcoming Matches',
            actionText: 'See all',
            onAction: () => widget.onGoTo?.call(1),
          ),
        ),
        SliverToBoxAdapter(
          child: filtered.isEmpty
              ? const SizedBox(
                  height: 136,
                  child: Center(child: Text('No matches scheduled.', style: TextStyle(color: textMuted))),
                )
              : _ResponsiveMatchList(matches: filtered, context: context),
        ),

        // Sub tabs
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Row(
              children: List.generate(subs.length, (i) {
                final active = i == subTab;
                return Expanded(
                  child: InkWell(
                    onTap: () => setState(() => subTab = i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(
                            color: active ? accent : Colors.transparent,
                            width: 2,
                          ),
                        ),
                      ),
                      child: Text(
                        subs[i],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: active ? Colors.white : textMuted,
                          fontWeight: active ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),

        if (subTab == 0) ...[
          SliverToBoxAdapter(
            child: SectionHeader(title: 'Latest Updates', actionText: ''),
          ),
          SliverToBoxAdapter(
            child: Column(
              children: feed.map((f) => FeedTile(item: f)).toList(),
            ),
          ),
          SliverToBoxAdapter(child: _InfoCard(
            icon: Icons.notifications_active_outlined,
            title: 'Never miss a match',
            text: 'Follow your favorite teams and get reminders before their games start.',
          )),
        ] else if (subTab == 1)
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (context, i) {
                final match = filtered[i];
                return ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  leading: CircleAvatar(
                    backgroundColor: cardAlt,
                    child: Text(match.game[0], style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                  title: Text('${match.teamA} vs ${match.teamB}'),
                  subtitle: Text('${match.league} • ${match.time}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => MatchDetail(match: match)),
                  ),
                );
              },
              childCount: filtered.length,
            ),
          )
        else if (subTab == 2)
          SliverToBoxAdapter(child: _NewsSection())
        else
          SliverToBoxAdapter(child: _RankingsSection()),
      ],
    );
  }
}


class _ResponsiveMatchList extends StatelessWidget {
  final List<GameMatch> matches;
  final BuildContext context;

  const _ResponsiveMatchList({required this.matches, required this.context});

  @override
  Widget build(BuildContext _) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final desktop = constraints.maxWidth >= 700;
        if (desktop) {
          final count = matches.length >= 4 ? 4 : matches.length;
          final gap = 12.0;
          final width = count == 0
              ? 160.0
              : (constraints.maxWidth - 32 - gap * (count - 1)) / count;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: gap,
              runSpacing: gap,
              children: matches.map((match) => SizedBox(
                width: width.clamp(160.0, 260.0).toDouble(),
                height: 146,
                child: MatchCard(
                  match: match,
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => MatchDetail(match: match)),
                  ),
                ),
              )).toList(),
            ),
          );
        }

        return SizedBox(
          height: 146,
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            scrollDirection: Axis.horizontal,
            itemCount: matches.length,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (_, i) => SizedBox(
              width: 160,
              height: 146,
              child: MatchCard(
                match: matches[i],
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => MatchDetail(match: matches[i])),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  const _InfoCard({required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) => Container(
    margin: const EdgeInsets.fromLTRB(16, 12, 16, 24),
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [accent.withValues(alpha: .16), card],
      ),
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: accent.withValues(alpha: .25)),
    ),
    child: Row(children: [
      const Icon(Icons.bolt, color: accent, size: 30),
      const SizedBox(width: 12),
      Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(text, style: const TextStyle(color: textMuted, fontSize: 12)),
        ],
      )),
    ]),
  );
}

class _NewsSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Column(
    children: [
      _NewsCard(icon: Icons.newspaper, title: 'VALORANT Patch 9.08', subtitle: 'New balance changes and competitive updates are now available.', time: '5h ago'),
      _NewsCard(icon: Icons.emoji_events, title: 'VCT Americas Stage 2', subtitle: 'The latest match schedule has been updated.', time: '2h ago'),
      _NewsCard(icon: Icons.campaign, title: 'Tournament Watch', subtitle: 'Keep an eye on today’s biggest esports matches.', time: 'Today'),
    ],
  );
}

class _NewsCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle, time;
  const _NewsCard({required this.icon, required this.title, required this.subtitle, required this.time});

  @override
  Widget build(BuildContext context) => Card(
    color: card,
    margin: const EdgeInsets.fromLTRB(16, 5, 16, 8),
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Row(children: [
        Container(
          width: 46, height: 46,
          decoration: BoxDecoration(color: accent.withValues(alpha: .12), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: accent),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            Text(subtitle, style: const TextStyle(color: textMuted, fontSize: 12)),
            const SizedBox(height: 5),
            Text(time, style: const TextStyle(color: textMuted, fontSize: 11)),
          ],
        )),
      ]),
    ),
  );
}

class _RankingsSection extends StatelessWidget {
  final List<String> teams = const ['FNATIC', 'Gen.G', 'Sentinels', 'NAVI', 'Paper Rex'];
  @override
  Widget build(BuildContext context) => Column(
    children: List.generate(teams.length, (i) => Card(
      color: card,
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 5),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: i == 0 ? accent.withValues(alpha: .18) : cardAlt,
          child: Text('${i + 1}', style: TextStyle(color: i == 0 ? accent : Colors.white, fontWeight: FontWeight.bold)),
        ),
        title: Text(teams[i], style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('Global ranking • ${1000 - i * 34} pts', style: const TextStyle(color: textMuted)),
        trailing: Icon(i < 2 ? Icons.trending_up : Icons.remove, color: i < 2 ? success : textMuted),
      ),
    )),
  );
}

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final TextEditingController controller = TextEditingController();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = controller.text.trim().toLowerCase();
    final results = matches.where((m) {
      if (query.isEmpty) return true;
      return [m.teamA, m.teamB, m.league, m.game]
          .any((value) => value.toLowerCase().contains(query));
    }).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Search')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(
            controller: controller,
            autofocus: true,
            onChanged: (_) => setState(() {}),
            decoration: const InputDecoration(
              prefixIcon: Icon(Icons.search),
              hintText: 'Search teams, games, or leagues',
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: results.isEmpty
                ? const Center(child: Text('No matches found.', style: TextStyle(color: textMuted)))
                : ListView.builder(
                    itemCount: results.length,
                    itemBuilder: (context, index) {
                      final match = results[index];
                      return ListTile(
                        title: Text('${match.teamA} vs ${match.teamB}'),
                        subtitle: Text('${match.game} • ${match.league} • ${match.time}'),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => MatchDetail(match: match)),
                        ),
                      );
                    },
                  ),
          ),
        ]),
      ),
    );
  }
}
