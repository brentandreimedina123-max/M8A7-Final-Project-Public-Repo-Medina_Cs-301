import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/app_bar.dart';

class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});
  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  bool notifications = true;
  bool compactScores = false;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        UnrealAppBar(title: 'Profile').build(context),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [accent.withValues(alpha: .18), card]),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: accent.withValues(alpha: .22)),
          ),
          child: Row(children: [
            const CircleAvatar(
              radius: 35,
              backgroundColor: cardAlt,
              child: Icon(Icons.person, size: 38),
            ),
            const SizedBox(width: 15),
            const Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Guest', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                SizedBox(height: 4),
                Text('Esports fan', style: TextStyle(color: textMuted)),
                SizedBox(height: 8),
                Text('Follow teams and never miss a match.', style: TextStyle(fontSize: 12)),
              ],
            )),
          ]),
        ),
        const SizedBox(height: 22),
        const Text('Preferences', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          color: card,
          child: Column(children: [
            SwitchListTile(
              value: notifications,
              onChanged: (value) => setState(() => notifications = value),
              activeColor: accent,
              secondary: const Icon(Icons.notifications_active_outlined),
              title: const Text('Match notifications'),
              subtitle: const Text('Get reminders for followed teams', style: TextStyle(color: textMuted)),
            ),
            const Divider(height: 1, color: divider),
            SwitchListTile(
              value: compactScores,
              onChanged: (value) => setState(() => compactScores = value),
              activeColor: accent,
              secondary: const Icon(Icons.view_agenda_outlined),
              title: const Text('Compact score cards'),
              subtitle: const Text('Use a smaller match card layout', style: TextStyle(color: textMuted)),
            ),
          ]),
        ),
        const SizedBox(height: 18),
        const Text('About', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Card(
          color: card,
          child: Column(children: [
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('About UnReal Time'),
              subtitle: const Text('Version 1.0.0', style: TextStyle(color: textMuted)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => showAboutDialog(
                context: context,
                applicationName: 'UnReal Time',
                applicationVersion: '1.0.0',
                children: const [
                  Text('An esports schedule, live score and update app made for esports fans.'),
                ],
              ),
            ),
            const Divider(height: 1, color: divider),
            ListTile(
              leading: const Icon(Icons.help_outline),
              title: const Text('How it works'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('How UnReal Time works'),
                  content: const Text(
                    'Choose a game to see its matches. Open a match for details, use the star to follow it and check the home feed for updates.',
                  ),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Got it')),
                  ],
                ),
              ),
            ),
          ]),
        ),
      ],
    );
  }
}
