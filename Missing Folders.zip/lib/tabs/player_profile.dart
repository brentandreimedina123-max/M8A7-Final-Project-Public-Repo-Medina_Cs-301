import 'package:flutter/material.dart';
import '../models/mock_data.dart';
import '../theme.dart';

class PlayerProfile extends StatelessWidget {
  final Player player;
  const PlayerProfile({super.key, required this.player});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Player Profile'),
        actions: [
          ValueListenableBuilder<Set<String>>(
            valueListenable: favoriteItems,
            builder: (_, favorites, __) => IconButton(
              tooltip: favorites.contains(player.id) ? 'Remove from favorites' : 'Add to favorites',
              onPressed: () => toggleFavorite(player.id),
              icon: Icon(favorites.contains(player.id) ? Icons.star : Icons.star_border, color: favorites.contains(player.id) ? accent : null),
            ),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Center(child: CircleAvatar(radius: 48, backgroundColor: accent.withValues(alpha:.14), child: Text(player.name[0], style: const TextStyle(fontSize: 38, color: accent, fontWeight: FontWeight.bold)))),
          const SizedBox(height: 14),
          Center(child: Text(player.name, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold))),
          Center(child: Text(player.realName, style: const TextStyle(color: textMuted))),
          const SizedBox(height: 20),
          Card(color: card, child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Player Information', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            _info(Icons.groups, 'Team', player.team), _info(Icons.sports_esports, 'Game', player.game), _info(Icons.shield_outlined, 'Role', player.role), _info(Icons.flag, 'Country', player.country), _info(Icons.tag, 'Player Number', '#${player.number}'),
          ]))),
          const SizedBox(height: 16),
          Card(color: card, child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('About', style: TextStyle(fontSize:18,fontWeight:FontWeight.bold)), const SizedBox(height:8), Text(player.bio, style: const TextStyle(color:textMuted, height:1.5))]))),
          const SizedBox(height: 18),
          ValueListenableBuilder<Set<String>>(
            valueListenable: favoriteItems,
            builder: (_, favorites, __) => FilledButton.icon(onPressed: () => toggleFavorite(player.id), icon: Icon(favorites.contains(player.id) ? Icons.star : Icons.star_border), label: Text(favorites.contains(player.id) ? 'Remove from Favorites' : 'Add to Favorites')),
          ),
        ],
      ),
    );
  }
  Widget _info(IconData icon, String label, String value) => Padding(padding: const EdgeInsets.only(bottom:11), child: Row(children:[Icon(icon,size:20,color:accent),const SizedBox(width:10),Expanded(child:Text(label,style:const TextStyle(color:textMuted))),Text(value,style:const TextStyle(fontWeight:FontWeight.bold))]));
}
