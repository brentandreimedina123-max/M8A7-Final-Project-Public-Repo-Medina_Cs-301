import 'package:flutter/material.dart';
import '../models/mock_data.dart';
import '../widgets/match_card.dart';
import '../theme.dart';
import 'match_detail.dart';

class GamePage extends StatelessWidget {
  final String game;
  const GamePage({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    final list = matches.where((m) => m.game == game).toList();
    final live = liveMatches.where((m) => m.game == game).toList();

    return Scaffold(
      appBar: AppBar(title: Text(game)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: accent.withValues(alpha: .15),
              child: Text(game[0], style: const TextStyle(color: accent, fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(game, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              Text('${live.length} live • ${list.length} upcoming', style: const TextStyle(color: textMuted)),
            ]),
          ]),
          const SizedBox(height: 22),
          if (live.isNotEmpty) ...[
            const Text('Live Now', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ...live.map((match) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: SizedBox(
                height: 146,
                child: MatchCard(
                  match: match,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MatchDetail(match: match))),
                ),
              ),
            )),
            const SizedBox(height: 8),
          ],
          const Text('Upcoming Matches', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          if (list.isEmpty)
            const Card(
              color: card,
              child: Padding(
                padding: EdgeInsets.all(25),
                child: Center(child: Text('No scheduled matches yet.', style: TextStyle(color: textMuted))),
              ),
            )
          else
            ...list.map((match) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: SizedBox(
                height: 146,
                child: MatchCard(
                  match: match,
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MatchDetail(match: match))),
                ),
              ),
            )),
        ],
      ),
    );
  }
}
