import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/mock_data.dart';
import '../widgets/app_bar.dart';
import 'player_profile.dart';
import 'team_profile.dart';

class FollowingTab extends StatefulWidget {
  final ValueChanged<int>? onGoTo;
  const FollowingTab({super.key, this.onGoTo});
  @override State<FollowingTab> createState() => _FollowingTabState();
}
class _FollowingTabState extends State<FollowingTab> {
  @override Widget build(BuildContext context) => ValueListenableBuilder<Set<String>>(
    valueListenable: favoriteItems,
    builder: (context, favorites, _) {
      final favoritePlayers = players.where((p)=>favorites.contains(p.id)).toList();
      final favoriteTeams = teams.where((t)=>favorites.contains('team:${t.name}')).toList();
      final oldItems = favorites.where((id)=>!players.any((p)=>p.id==id)&&!teams.any((t)=>'team:${t.name}'==id)).toList();
      final count = favoritePlayers.length + favoriteTeams.length + oldItems.length;
      return ListView(padding:const EdgeInsets.fromLTRB(16,8,16,24),children:[
        UnrealAppBar(title:'Following').build(context), const SizedBox(height:8),
        Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(18),border:Border.all(color:divider)),child:Row(children:[const Icon(Icons.star,color:accent,size:30),const SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Your Favorites',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:3),Text('$count teams, players and events followed',style:const TextStyle(color:textMuted))]))])),
        const SizedBox(height:22),
        if(count==0) Card(color:card,child:Padding(padding:const EdgeInsets.all(28),child:Column(children:[const Icon(Icons.star_border,size:54,color:textMuted),const SizedBox(height:12),const Text('Nothing followed yet',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:6),const Text('Open a player, team or match and tap the star to add it here.',textAlign:TextAlign.center,style:TextStyle(color:textMuted)),const SizedBox(height:16),FilledButton.icon(onPressed:()=>widget.onGoTo?.call(0),icon:const Icon(Icons.explore),label:const Text('Explore matches'))])))
        else ...[
          if(favoritePlayers.isNotEmpty)...[const Text('Players',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:9),...favoritePlayers.map((p)=>Card(color:card,margin:const EdgeInsets.only(bottom:8),child:ListTile(leading:CircleAvatar(backgroundColor:cardAlt,child:Text(p.name[0],style:const TextStyle(color:accent,fontWeight:FontWeight.bold))),title:Text(p.name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${p.team} • ${p.role}',style:const TextStyle(color:textMuted)),trailing:IconButton(icon:const Icon(Icons.star,color:accent),onPressed:()=>toggleFavorite(p.id)),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>PlayerProfile(player:p))))))],
          if(favoriteTeams.isNotEmpty)...[const SizedBox(height:12),const Text('Teams',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:9),...favoriteTeams.map((t)=>Card(color:card,margin:const EdgeInsets.only(bottom:8),child:ListTile(leading:CircleAvatar(backgroundColor:cardAlt,child:Text(t.name[0],style:const TextStyle(color:accent,fontWeight:FontWeight.bold))),title:Text(t.name,style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${t.game} • ${t.region}',style:const TextStyle(color:textMuted)),trailing:IconButton(icon:const Icon(Icons.star,color:accent),onPressed:()=>toggleFavorite('team:${t.name}')),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>TeamProfile(team:t))))))],
          if(oldItems.isNotEmpty)...[const SizedBox(height:12),const Text('Other Favorites',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:9),...oldItems.map((f)=>Card(color:card,child:ListTile(leading:const Icon(Icons.star,color:accent),title:Text(f),subtitle:const Text('Following updates',style:TextStyle(color:textMuted)),trailing:IconButton(icon:const Icon(Icons.star,color:accent),onPressed:()=>toggleFavorite(f)))))]
        ],
      ]);
    },
  );
}
