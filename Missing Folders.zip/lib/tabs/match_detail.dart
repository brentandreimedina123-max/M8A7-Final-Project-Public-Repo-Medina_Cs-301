import 'package:flutter/material.dart';
import '../models/mock_data.dart';
import '../theme.dart';
import 'team_profile.dart';

class MatchDetail extends StatelessWidget {
  final GameMatch match;
  const MatchDetail({super.key,required this.match});
  @override Widget build(BuildContext context){
    final a=_findTeam(_teamFull(match.teamA));
    final b=_findTeam(_teamFull(match.teamB));
    return Scaffold(appBar:AppBar(title:Text(match.league),actions:[ValueListenableBuilder<Set<String>>(valueListenable:favoriteItems,builder:(_,f,__)=>IconButton(onPressed:()=>toggleFavorite('match:${match.id}'),icon:Icon(f.contains('match:${match.id}')?Icons.star:Icons.star_border,color:f.contains('match:${match.id}')?accent:null)))]),body:ListView(padding:const EdgeInsets.all(20),children:[Center(child:Text(match.game,style:const TextStyle(color:textMuted))),const SizedBox(height:22),Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[_team(context,match.teamA,match.scoreA,a),Column(children:[Text(match.live?'LIVE':match.time,style:TextStyle(color:match.live?success:Colors.white,fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:6),Text(match.startsIn,style:const TextStyle(color:textMuted))]),_team(context,match.teamB,match.scoreB,b)]),const SizedBox(height:28),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Match information',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),const SizedBox(height:12),Text('Tournament: ${match.league}'),Text('Status: ${match.live?'Live':'Upcoming'}'),Text('Match ID: ${match.id}')]))]));
  }
  Widget _team(BuildContext context,String name,String score,TeamInfo? team)=>InkWell(borderRadius:BorderRadius.circular(14),onTap:team==null?null:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>TeamProfile(team:team))),child:Column(children:[CircleAvatar(radius:34,backgroundColor:cardAlt,child:Text(name[0],style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold))),const SizedBox(height:8),Text(name,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),Text(score,style:const TextStyle(color:textMuted)),if(team!=null)const Text('View team',style:TextStyle(color:accent,fontSize:11))]));
  TeamInfo? _findTeam(String name){ for(final t in teams){ if(t.name.toLowerCase()==name.toLowerCase()) return t; } return null; }
  String _teamFull(String short)=>{'SEN':'Sentinels','PRX':'Paper Rex','NAVI':'NAVI','G2':'G2','FNC':'Fnatic','T1':'T1','GEN':'Gen.G','3DMAX':'3DMAX','GG':'Gaimin Gladiators','XG':'Xtreme Gaming'}[short]??short;
}
