import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/mock_data.dart';
import '../widgets/app_bar.dart';
import 'game_page.dart';
import 'team_profile.dart';
import 'player_profile.dart';

class EsportsTab extends StatelessWidget {
  const EsportsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final liveCount = liveMatches.length;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      children: [
        UnrealAppBar(title: 'Esports').build(context),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [accent.withValues(alpha: .18), card]),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: accent.withValues(alpha: .25)),
          ),
          child: Row(children: [
            const CircleAvatar(
              radius: 28,
              backgroundColor: accent,
              child: Icon(Icons.flash_on, color: Colors.white, size: 30),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Esports Hub', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text('$liveCount matches live • ${matches.length} upcoming', style: const TextStyle(color: textMuted)),
              ],
            )),
          ]),
        ),
        const SizedBox(height: 24),
        const Text('Games', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...games.map((g) {
          final count = matches.where((m) => m.game == g).length;
          final live = liveMatches.where((m) => m.game == g).length;
          return Card(
            color: card,
            margin: const EdgeInsets.only(bottom: 9),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
              leading: CircleAvatar(
                backgroundColor: accent.withValues(alpha: .12),
                child: Text(g[0], style: const TextStyle(color: accent, fontWeight: FontWeight.bold)),
              ),
              title: Text(g, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(
                live > 0 ? '$live live • $count upcoming matches' : '$count upcoming matches',
                style: const TextStyle(color: textMuted),
              ),
              trailing: const Icon(Icons.chevron_right, color: textMuted),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => GamePage(game: g)),
              ),
            ),
          );
        }),
        const SizedBox(height: 20),
        const Text('Teams', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...teams.map((team) => Card(
          color: card,
          margin: const EdgeInsets.only(bottom: 9),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
            leading: CircleAvatar(
              backgroundColor: accent.withValues(alpha: .12),
              child: Text(team.name[0], style: const TextStyle(color: accent, fontWeight: FontWeight.bold)),
            ),
            title: Text(team.name, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${team.game} • ${team.region} • ${team.playerIds.length} players', style: const TextStyle(color: textMuted)),
            trailing: const Icon(Icons.chevron_right, color: textMuted),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TeamProfile(team: team))),
          ),
        )),
        const SizedBox(height: 20),
        const Text('Players', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...players.map((player) => Card(
          color: card,
          margin: const EdgeInsets.only(bottom: 9),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: cardAlt,
              child: Text(player.name[0].toUpperCase(), style: const TextStyle(color: accent, fontWeight: FontWeight.bold)),
            ),
            title: Text(player.name, style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('${player.team} • ${player.role}', style: const TextStyle(color: textMuted)),
            trailing: ValueListenableBuilder<Set<String>>(
              valueListenable: favoriteItems,
              builder: (_, favorites, __) => IconButton(
                onPressed: () => toggleFavorite(player.id),
                icon: Icon(favorites.contains(player.id) ? Icons.star : Icons.star_border, color: favorites.contains(player.id) ? accent : textMuted),
              ),
            ),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerProfile(player: player))),
          ),
        )),
      ],
    );
  }
}
