import 'package:flutter/material.dart';
import '../models/mock_data.dart';
import '../theme.dart';
import 'player_profile.dart';

class TeamProfile extends StatelessWidget {
  final TeamInfo team;

  const TeamProfile({super.key, required this.team});

  @override
  Widget build(BuildContext context) {
    final roster = players.where((p) => team.playerIds.contains(p.id)).toList();
    final favoriteId = 'team:${team.name}';

    return Scaffold(
      appBar: AppBar(
        title: Text(team.name),
        actions: [
          ValueListenableBuilder<Set<String>>(
            valueListenable: favoriteItems,
            builder: (_, favorites, __) {
              final favorite = favorites.contains(favoriteId);
              return IconButton(
                tooltip: favorite ? 'Remove from favorites' : 'Add to favorites',
                onPressed: () => toggleFavorite(favoriteId),
                icon: Icon(
                  favorite ? Icons.star : Icons.star_border,
                  color: favorite ? accent : null,
                ),
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: card,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: divider),
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 34,
                  backgroundColor: accent.withValues(alpha: .14),
                  child: Text(
                    team.name[0],
                    style: const TextStyle(
                      color: accent,
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        team.name,
                        style: const TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        '${team.game} • ${team.region}',
                        style: const TextStyle(color: textMuted),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        team.description,
                        style: const TextStyle(color: textMuted, height: 1.35),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Players', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              Text('${roster.length} players', style: const TextStyle(color: textMuted)),
            ],
          ),
          const SizedBox(height: 10),
          ...roster.map(
            (player) => Card(
              color: card,
              margin: const EdgeInsets.only(bottom: 9),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: cardAlt,
                  child: Text(
                    player.name[0].toUpperCase(),
                    style: const TextStyle(
                      color: accent,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                title: Text(
                  player.name,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  '${player.role} • ${player.country}',
                  style: const TextStyle(color: textMuted),
                ),
                trailing: const Icon(
                  Icons.chevron_right,
                  color: textMuted,
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => PlayerProfile(player: player),
                    ),
                  );
                },
              ),
            ),
          ),
          if (roster.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 30),
              child: Center(
                child: Text(
                  'No players listed for this team yet.',
                  style: TextStyle(color: textMuted),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
