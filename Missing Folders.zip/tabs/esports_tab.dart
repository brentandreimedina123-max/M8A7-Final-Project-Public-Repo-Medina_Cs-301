import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/mock_data.dart';

class EsportsTab extends StatelessWidget {
  const EsportsTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Esports', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        for (final g in games)
          Card(
            color: card,
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: const Icon(Icons.sports_esports, color: accent),
              title: Text(g),
              trailing: const Icon(Icons.chevron_right, color: textMuted),
            ),
          ),
      ],
    );
  }
}
