import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/mock_data.dart';

class FollowingTab extends StatelessWidget {
  const FollowingTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('Following', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
        const SizedBox(height: 16),
        for (final f in followed)
          ListTile(
            leading: const CircleAvatar(backgroundColor: cardAlt, child: Icon(Icons.star, color: accent)),
            title: Text(f),
          ),
      ],
    );
  }
}
