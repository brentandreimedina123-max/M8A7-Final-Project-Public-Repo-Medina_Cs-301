import 'package:flutter/material.dart';
import '../theme.dart';

class ProfileTab extends StatelessWidget {
  const ProfileTab({super.key});
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: const [
          CircleAvatar(radius: 36, backgroundColor: cardAlt, child: Icon(Icons.person, size: 36)),
          SizedBox(height: 12),
          Text('Guest', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          SizedBox(height: 4),
          Text('Sign in — TODO', style: TextStyle(color: textMuted)),
        ],
      ),
    );
  }
}
