import 'package:flutter/material.dart';
import '../theme.dart';
import '../models/mock_data.dart';
import '../widgets/match_card.dart';
import '../widgets/feed_tile.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});
  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  int _gameIndex = 0;
  int _subTab = 0; // Feed / Matches / News / Rankings
  final _subTabs = const ['Feed', 'Matches', 'News', 'Rankings'];

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        // Game selector row
        SliverToBoxAdapter(
          child: SizedBox(
            height: 44,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              scrollDirection: Axis.horizontal,
              itemCount: games.length,
              separatorBuilder: (_, __) => const SizedBox(width: 20),
              itemBuilder: (_, i) => GestureDetector(
                onTap: () => setState(() => _gameIndex = i),
                child: Center(
                  child: Text(
                    games[i],
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: i == _gameIndex ? Colors.white : textMuted,
                      decoration: i == _gameIndex ? TextDecoration.underline : null,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        // Match cards row
        SliverToBoxAdapter(
          child: SizedBox(
            height: 140,
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemCount: matches.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, i) => MatchCard(match: matches[i]),
            ),
          ),
        ),
        // Sub-tab bar (Feed/Matches/News/Rankings)
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.only(top: 12),
            child: Row(
              children: List.generate(_subTabs.length, (i) {
                final active = i == _subTab;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _subTab = i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        border: Border(
                          bottom: BorderSide(color: active ? Colors.white : Colors.transparent, width: 2),
                        ),
                      ),
                      child: Text(
                        _subTabs[i],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: active ? Colors.white : textMuted,
                          fontWeight: active ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ),
                  ),
                );
              }),
            ),
          ),
        ),
        // Feed list (only real content wired up; other sub-tabs show placeholder)
        if (_subTab == 0)
          SliverList(
            delegate: SliverChildBuilderDelegate(
              (_, i) => FeedTile(item: feed[i]),
              childCount: feed.length,
            ),
          )
        else
          SliverFillRemaining(
            hasScrollBody: false,
            child: Center(
              child: Text('${_subTabs[_subTab]} — TODO', style: const TextStyle(color: textMuted)),
            ),
          ),
      ],
    );
  }
}
